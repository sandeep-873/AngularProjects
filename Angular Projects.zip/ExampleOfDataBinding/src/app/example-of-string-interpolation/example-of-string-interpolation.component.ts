import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';

@Component({
  selector: 'app-example-of-string-interpolation',
  templateUrl: './example-of-string-interpolation.component.html',
  styleUrls: ['./example-of-string-interpolation.component.css']
})
export class ExampleOfStringInterpolationComponent  {

  i:number=90;
  str:string="NCS India";
  isActivated:boolean=true;

  FirstName:string="Saurabh";
  LastName:string="Agarwal";
  Gender:string="Male";
  Qualification:string="MCA";

  empNameArr:string[]=["Aishwarya","kalyani","Hemant","Vishal","Pradeep","Surya","Wahid","Vashnavi"]
  name0=this.empNameArr[0];
  name1=this.empNameArr[1];
  name2=this.empNameArr[2];
  name3=this.empNameArr[3];
  name4=this.empNameArr[4];
  name5=this.empNameArr[5];
  name6=this.empNameArr[6];
  name7=this.empNameArr[7];

  months:string[]=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"]

  DayWeeksArray:string[]=["Monday", "Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]

  //Creating the Functions

  addition(x:number, y:number): number{
    return x+y;
  }

  substraction(x:number, y:number): number{
    return x-y;
  }

  multipliaction(x:number, y:number): number{
    return x*y;
  }

  divison(x:number, y:number): number{
    return x/y;
  }

  //Create the Json Array
  empJsonArray=[
    {"FirstName":"Saurabh","LastName":"Agarwal","Age":39,"Gender":"Male"},
    {"FirstName":"Ankur","LastName":"Agarwal","Age":38,"Gender":"Male"},
    {"FirstName":"Himani","LastName":"Arora","Age":39,"Gender":"Female"},
    {"FirstName":"Gaurav","LastName":"Sharma","Age":42,"Gender":"Male"},
    {"FirstName":"Supriya","LastName":"Singh","Age":32,"Gender":"Female"},
    {"FirstName":"Vishal","LastName":"Singh","Age":35,"Gender":"Male"}
  ]

  employeeData=[
    new Employee(1,"Saurabh",20000,"Noida"),
    new Employee(2,"Hemant",30000,"Pune"),
    new Employee(3,"Aishwarya",50000,"Mumbai"),
    new Employee(4,"Vishal",80000,"Mumbai"),
    new Employee(5,"Wahid",60000,"Pune"),
    new Employee(6,"Pradeep",70000,"Pune"),
    new Employee(7,"Vaisnavi",70000,"Mumbai"),
  ]

}
