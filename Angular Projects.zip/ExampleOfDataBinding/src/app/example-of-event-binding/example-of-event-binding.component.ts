import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-of-event-binding',
  templateUrl: './example-of-event-binding.component.html',
  styleUrls: ['./example-of-event-binding.component.css']
})
export class ExampleOfEventBindingComponent  {

  public name='';
  sum:number;
  sub:number;
  mul:number;
  div:number;
  SetName(){
    this.name="NCS India";
  }
  ClearMessage(){
    this.name="";
  }

  additon(a:number, b:number):number{
    return a+b;
  }
  substraction(a:number, b:number):number{
    return a-b;
  }
  multiplication(a:number, b:number):number{
    return a*b;
  }
  divison(a:number, b:number):number{
    return a/b;
  }

}
