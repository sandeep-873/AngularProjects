import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { ExampleOfStringInterpolationComponent } from './example-of-string-interpolation/example-of-string-interpolation.component';
import { ExampleOfPropertyBindingComponent } from './example-of-property-binding/example-of-property-binding.component';
import { ExampleOfEventBindingComponent } from './example-of-event-binding/example-of-event-binding.component';
import { ExampleOfTwoWayDataBindingComponent } from './example-of-two-way-data-binding/example-of-two-way-data-binding.component';

@NgModule({
  declarations: [
    AppComponent,
    ExampleOfStringInterpolationComponent,
    ExampleOfPropertyBindingComponent,
    ExampleOfEventBindingComponent,
    ExampleOfTwoWayDataBindingComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
