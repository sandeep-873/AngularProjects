export class Employee{
    empId:number;
    empName:string;
    empSal:number;
    empAddress:string;

    constructor(_empId, _empName, _empSal, _empAddress){
        this.empId=_empId;
        this.empName=_empName;
        this.empSal=_empSal;
        this.empAddress=_empAddress;

    }
}