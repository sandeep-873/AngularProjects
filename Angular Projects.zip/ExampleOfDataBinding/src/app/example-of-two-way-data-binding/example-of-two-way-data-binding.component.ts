import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-of-two-way-data-binding',
  templateUrl: './example-of-two-way-data-binding.component.html',
  styleUrls: ['./example-of-two-way-data-binding.component.css']
})
export class ExampleOfTwoWayDataBindingComponent  {

  public name='';

}
