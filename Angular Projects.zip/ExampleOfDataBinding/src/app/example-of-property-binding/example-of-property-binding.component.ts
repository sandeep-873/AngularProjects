import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-of-property-binding',
  templateUrl: './example-of-property-binding.component.html',
  styleUrls: ['./example-of-property-binding.component.css']
})
export class ExampleOfPropertyBindingComponent {

  public color="green";
  public size="30px";
  public fontStyle="italic";
  public fontWeight="bold";
  public backgroundColor="yellow";
  public border="5px solid red";

  employeeObject={
    name:'Click Google',
    url:'http://www.google.com',
    description:'Learning Angular with .Net Core',
    logo:'../assets/NCSLogo.png'
  }

}
