import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent  {

  customers:Customer[]=[
    {"customerNo": 1, "customerName": "Saurabh", "address": 'Noida', "city": 'Noida', "state": 'Uttar Pradesh', "country": 'India'},
    {"customerNo": 2, "customerName": "Pradeep", "address": '', "city": 'Dallas', "state": 'Maharastra', "country": 'USA'},
    {"customerNo": 3, "customerName": 'Vishal', "address": '', "city": 'Kolkata', "state": 'West Bengal', "country": 'UK'},
    {"customerNo": 4, "customerName": 'Kalyani', "address": '', "city": 'Ranchi', "state": 'Bihar', "country": 'India'},
    {"customerNo": 5, "customerName": 'Hemant', "address": '', "city": 'Delhi', "state": 'Delhi', "country": 'India'},
    {"customerNo": 6, "customerName": 'Surya', "address": 'Sweden', "city": 'Stockholm', "state": 'Kungsholmen', "country": 'Sweden'},
    {"customerNo": 7, "customerName": 'Anand', "address": 'Hyderabad', "city": 'Telganana', "state": 'AP', "country": 'India'},
    {"customerNo": 8, "customerName": 'Sagar', "address": 'Kolkatta', "city": 'Kolkatta', "state": 'West Bengal', "country": 'India'},
  ]

  selectedCustomer:Customer;

  showDetails(customer: Customer){
    this.selectedCustomer=Object.assign({}, customer);
    console.log(this.selectedCustomer);
    
  }

  Update(customer: Customer){
    console.log(customer);
    var cust=this.customers.find(e=>e.customerNo==customer.customerNo)
    Object.assign(cust, customer);
    alert('Customer Saved');
    

  }


}
