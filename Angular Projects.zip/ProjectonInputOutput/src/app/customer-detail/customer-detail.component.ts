import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

import { Customer } from '../Customer';

@Component({
  selector: 'app-customer-detail',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.css']
})
export class CustomerDetailComponent  {

  @Input() customer:Customer
  @Output() customerChange: EventEmitter<Customer>=new EventEmitter<Customer>();
  
  Update(){
    this.customerChange.emit(this.customer);

  }
}
