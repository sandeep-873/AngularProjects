export class Customer {
    customerNo: number;
    customerName: string;
    address: string;
    country: string;
    state: string;
    city: string;
}