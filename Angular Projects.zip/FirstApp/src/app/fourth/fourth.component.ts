import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fourth',
  templateUrl: './fourth.component.html',
  styles: [
  ]
})
export class FourthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
