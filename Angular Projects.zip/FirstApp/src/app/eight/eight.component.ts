import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eight',
  template: `
  <h1>Eight Component Creation</h1>
  <h3>Inline Template</h3>
  `,
  styles: [
  ]
})
export class EightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
