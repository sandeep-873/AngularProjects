import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { ThridComponent } from './thrid/thrid.component';
import { FourthComponent } from './fourth/fourth.component';
import { FifthComponent } from './fifth/fifth.component';
import { EightComponent } from './eight/eight.component';
import { NinthComponent } from './ninth/ninth.component';
import { SubNinthComponent } from './ninth/sub-ninth/sub-ninth.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent,
    ThridComponent,
    FourthComponent,
    FifthComponent,
    EightComponent,
    NinthComponent,
    SubNinthComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
