import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thrid',
  templateUrl: './thrid.component.html',
  styleUrls: ['./thrid.component.css']
})
export class ThridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
