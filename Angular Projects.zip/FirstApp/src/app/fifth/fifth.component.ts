import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fifth',
  templateUrl: './fifth.component.html',
  styles: [
  ]
})
export class FifthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
