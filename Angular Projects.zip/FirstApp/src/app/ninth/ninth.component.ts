import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ninth',
  templateUrl: './ninth.component.html',
  styles: [
  ]
})
export class NinthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
