import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-ninth',
  template: `
    <h1>Sub Ninth Component Creation</h1>
  `,
  styles: [
  ]
})
export class SubNinthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
