import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ExampleOfInbuiltPipesComponent } from './example-of-inbuilt-pipes/example-of-inbuilt-pipes.component';
import { AgePipe } from './age.pipe';
import { EmployeeTitlePipe } from './employee-title.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ExampleOfInbuiltPipesComponent,
    AgePipe,
    EmployeeTitlePipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
