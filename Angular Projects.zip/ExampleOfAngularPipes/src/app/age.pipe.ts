import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'age'
})
export class AgePipe implements PipeTransform {

  transform(value: any) {
    console.log(value);
    let currentYear=new Date().getFullYear();
    console.log(currentYear);
    let userBirthYear=new Date(value).getFullYear();
    let userAge=currentYear - userBirthYear;
    return userAge;
}

}
