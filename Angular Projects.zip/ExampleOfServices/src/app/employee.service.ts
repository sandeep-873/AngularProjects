export class EmployeeService {
employees: any = [
    { "EmpCode": "E-101", "EmpName": "Saurabh", "EmpGender": "Male", "EmpQualification": "BTech", "EmpSalary": 20000 },
    { "EmpCode": "E-102", "EmpName": "Madhu", "EmpGender": "Female", "EmpQualification": "MCA", "EmpSalary": 20000 },
    { "EmpCode": "E-103", "EmpName": "Ankur", "EmpGender": "Male", "EmpQualification": "BCA", "EmpSalary": 20000 },
    { "EmpCode": "E-104", "EmpName": "Eleazer", "EmpGender": "Male", "EmpQualification": "BTech", "EmpSalary": 20000 },
    { "EmpCode": "E-105", "EmpName": "Padma", "EmpGender": "Female", "EmpQualification": "MTech", "EmpSalary": 900000 },
    { "EmpCode": "E-106", "EmpName": "Monika", "EmpGender": "Female", "EmpQualification": "BTech", "EmpSalary": 90000 }
  ]
  getEmployeeDetails(){
    return this.employees;
  }

}
