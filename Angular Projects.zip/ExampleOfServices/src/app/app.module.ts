import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { EmployeeInfoComponent } from './employee-info/employee-info.component';
import { EmployeeDetailComponent } from './employee-detail/employee-detail.component';
import {Routes, RouterModule} from '@angular/router';
import { ArithmeticComponent } from './arithmetic/arithmetic.component';

import {FormsModule} from '@angular/forms';

const routes:Routes=[
  {path :'EmployeeInfo' , component:EmployeeInfoComponent},
  {path :'EmployeeDetail' , component:EmployeeDetailComponent},
  {path :'ArithmeticOpeartions' , component:ArithmeticComponent}

]
@NgModule({
  declarations: [
    AppComponent,
    EmployeeInfoComponent,
    EmployeeDetailComponent,
    ArithmeticComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(routes),FormsModule
  ],
  exports:[RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
