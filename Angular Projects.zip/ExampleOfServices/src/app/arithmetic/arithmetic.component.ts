import { Component, OnInit } from '@angular/core';
import { ArithmeticOperationService } from '../arithmetic-operation.service';

@Component({
  selector: 'app-arithmetic',
  templateUrl: './arithmetic.component.html',
  styleUrls: ['./arithmetic.component.css'],
  providers:[ArithmeticOperationService]
})
export class ArithmeticComponent  {
  FirstNumber:number;
  SecondNumber:number;
  sum:number;

  constructor(private objArithmeticService :ArithmeticOperationService ) { }

  add():number{
    return this.objArithmeticService.addition(this.FirstNumber, this.SecondNumber);

  }

}
