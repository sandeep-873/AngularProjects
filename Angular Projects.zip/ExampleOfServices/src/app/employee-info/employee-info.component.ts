import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-info',
  templateUrl: './employee-info.component.html',
  styleUrls: ['./employee-info.component.css'],
  providers:[EmployeeService]
})
export class EmployeeInfoComponent  {

  employees:any;
  constructor( objEmployeeSevice: EmployeeService){
    //let objEmployeeSevice=new EmployeeService();
    this.employees= objEmployeeSevice.getEmployeeDetails();
  }
 
}
