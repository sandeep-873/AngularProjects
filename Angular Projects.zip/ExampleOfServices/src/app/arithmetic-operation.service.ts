export class ArithmeticOperationService {
  addition(x: number, y: number): number {
    return x + y;
  }

  substraction(x: number, y: number): number {
    return x - y;
  }

  multiplication(x: number, y: number): number {
    return x * y;
  }

  divison(x: number, y: number): number {
    return x / y;
  }
  
}
