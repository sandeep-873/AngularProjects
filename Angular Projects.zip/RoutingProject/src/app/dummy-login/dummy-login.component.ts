import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dummy-login',
  templateUrl: './dummy-login.component.html',
  styleUrls: ['./dummy-login.component.css']
})
export class DummyLoginComponent  {

  uname:string='';
  pwd:string='';
  msg:string='';
  
  constructor(private _router:Router){

  }


  validateUser(){

    if(this.uname=='saurabh' && this.pwd=="agarwal"){
      localStorage.setItem('uname',this.uname)
      this._router.navigate(['Dashboard'])

    }

  }

}
