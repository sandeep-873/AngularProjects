import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-dummy-dashboard',
  templateUrl: './dummy-dashboard.component.html',
  styleUrls: ['./dummy-dashboard.component.css']
})
export class DummyDashboardComponent {

  uname:string;
  msg:string;
  constructor(private _router:Router) {
    this.uname=localStorage.getItem('uname');
    if(this.uname!=null){
      this.msg="Hello " + ' '  + this.uname + " Welcome to Dashboard"
    }
    else{
      this.msg="Landed on this page";
      this._router.navigate(['Login'])
    }
   }

  

}
