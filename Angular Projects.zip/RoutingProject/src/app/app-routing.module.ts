import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { DummyDashboardComponent } from './dummy-dashboard/dummy-dashboard.component';
import { DummyLoginComponent } from './dummy-login/dummy-login.component';
import { EmployeeComponent } from './employee/employee.component';
import { GiftComponent } from './gift/gift.component';
import { HelpComponent } from './help/help.component';
import { IndexComponent } from './index/index.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { LogoutComponent } from './logout/logout.component';
import {Routes, RouterModule} from '@angular/router';
import {FormsModule} from '@angular/forms';

const routes:Routes=[
  {path:'', redirectTo:'Index',pathMatch:"full"},
  {path:'Index', component:IndexComponent},
  {path:'About', component:AboutComponent},
  {path:'Contact', component:ContactComponent},
  {path:'Help', component:HelpComponent},
  {path:'Login', component:DummyLoginComponent},
  {path:'Employee', component:EmployeeComponent},
  {path:'Dashboard', component:DummyDashboardComponent},
  {path:'Logout', component:LogoutComponent},
  {path:"**", component:NotFoundComponent}
]


@NgModule({
  declarations: [
    ContactComponent,
    AboutComponent,
    DummyDashboardComponent,
    DummyLoginComponent,
    EmployeeComponent,
    GiftComponent,
    HelpComponent,
    IndexComponent,
    NotFoundComponent,
    LogoutComponent
  ],
  imports: [
    CommonModule, RouterModule.forRoot(routes), FormsModule
  ],
  exports:[RouterModule]
})
export class AppRoutingModule { }
