import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent  {

  value:string;
  result:number;
  onClickParent(data:string){
    this.value=data;

  }

  onMyParentAddition(data:number){
    this.result=data;
  }
  onMyParentSubstraction(data:number){
    this.result=data;
  }

  onMyParentMultiplication(data:number){
    this.result=data;
  }
  onMyParentDivison(data:number){
    this.result=data;
  }

  onMyParentRectangle(data:number){
    this.result=data;
  }
  onMyParentSquare(data:number){
    this.result=data;
  }
  onMyParentCircle(data:number){
    this.result=data;
  }
}
