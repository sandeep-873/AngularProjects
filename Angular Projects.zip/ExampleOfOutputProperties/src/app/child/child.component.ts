import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent  {
  FirstNumber;
  SecondNumber;
  length;
  width;
  radius;

@Output() clicked:EventEmitter<string>=new EventEmitter<string>();

@Output() addition:EventEmitter<number>=new EventEmitter<number>();
@Output() substraction:EventEmitter<number>=new EventEmitter<number>();
@Output() multiplication:EventEmitter<number>=new EventEmitter<number>();
@Output() divison:EventEmitter<number>=new EventEmitter<number>();

@Output() areaofRectangle:EventEmitter<number>=new EventEmitter<number>();
@Output() areaofSquare:EventEmitter<number>=new EventEmitter<number>();
@Output() areaofCircle:EventEmitter<number>=new EventEmitter<number>();

areaRectangle(){
  this.areaofRectangle.emit(this.length * this.width)
}

areaSquare(){
  this.areaofSquare.emit(this.radius * this.radius)
}

areCircle(){
  this.areaofCircle.emit(3.14 * this.radius * this.radius)
}

onClicked()
{
this.clicked.emit("Custom Event fired");
}

add(){
  this.addition.emit(parseInt(this.FirstNumber) + parseInt(this.SecondNumber))

}
sub(){
  this.addition.emit(parseInt(this.FirstNumber) - parseInt(this.SecondNumber))
}
mul(){
  this.addition.emit(parseInt(this.FirstNumber) * parseInt(this.SecondNumber))
}
div(){
  this.addition.emit(parseInt(this.FirstNumber) / parseInt(this.SecondNumber))
}

}
