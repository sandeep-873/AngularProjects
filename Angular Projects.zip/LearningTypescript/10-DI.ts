export class Computer{
    processor:Processor;
    constructor(_processor:Processor){
       // this.processor=new Processor();
       this.processor=_processor;
        console.log("Computer Class Called");
        
    }
}

export class Processor{
    constructor(speed:number)
    {
        console.log(speed);
        
        console.log("Processor Class Called");
        
    }
}

let objComputer=new Computer(new Processor(10));
//let objProcessor=new Processor();