"use strict";
exports.__esModule = true;
exports.Employee = exports.Department = void 0;
var Department = /** @class */ (function () {
    function Department(_deptId, _deptName) {
        this.deptId = _deptId;
        this.deptName = _deptName;
        console.log("Department Id :: " + this.deptId + " Depatment Name :: " + this.deptName);
    }
    return Department;
}());
exports.Department = Department;
var Employee = /** @class */ (function () {
    function Employee(_department) {
        this.objDepartment = _department;
    }
    return Employee;
}());
exports.Employee = Employee;
var objEmployee = new Employee(new Department(1, "IT"));
objEmployee.empId = 101;
objEmployee.empName = "Vaibhav";
objEmployee.empSal = 200000;
console.log("Emp Id :: " + objEmployee.empId + "Emp Name :: " + objEmployee.empName
    + " Emp Sal :: " + objEmployee.empSal);
