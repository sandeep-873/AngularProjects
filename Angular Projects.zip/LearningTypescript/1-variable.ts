let i:number=20;
console.log("The variable i would be :: " + i);

let str:string="NCSI";
console.log("The variable str would be :: " + str);

let isActivated:boolean=true;
console.log("The variable isActivated would be :: " + isActivated);
