export class Department{
    public deptId:number;
    public deptName:string;

    constructor(_deptId:number, _deptName:string){
        this.deptId=_deptId;
        this.deptName=_deptName

        console.log("Department Id :: " + this.deptId + " Depatment Name :: " + this.deptName);
        
    }
}

export class Employee{
    public empId:number;
    public empName:string;
    public empSal:number;
    public objDepartment:Department;

    constructor(_department: Department){
        this.objDepartment=_department;

    }
}

let objEmployee=new Employee(new Department(1,"IT"));
objEmployee.empId=101;
objEmployee.empName="Vaibhav";
objEmployee.empSal=200000;

console.log("Emp Id :: " + objEmployee.empId + " Emp Name :: " + objEmployee.empName
 + " Emp Sal :: " + objEmployee.empSal);
