"use strict";
exports.__esModule = true;
exports.Processor = exports.Computer = void 0;
var Computer = /** @class */ (function () {
    function Computer(_processor) {
        // this.processor=new Processor();
        this.processor = _processor;
        console.log("Computer Class Called");
    }
    return Computer;
}());
exports.Computer = Computer;
var Processor = /** @class */ (function () {
    function Processor(speed) {
        console.log(speed);
        console.log("Processor Class Called");
    }
    return Processor;
}());
exports.Processor = Processor;
var objComputer = new Computer(new Processor(10));
//let objProcessor=new Processor();
