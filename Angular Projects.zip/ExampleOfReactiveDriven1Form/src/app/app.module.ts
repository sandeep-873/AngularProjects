import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ExampleOfReactiveDrivenFormComponent } from './example-of-reactive-driven-form/example-of-reactive-driven-form.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule,Routes} from '@angular/router';
import { ExampleOfNestedReactiveDrivenFormComponent } from './example-of-nested-reactive-driven-form/example-of-nested-reactive-driven-form.component';
import { ExampleOfReactiveDrivebFormWithSetValueAndPatchValueComponent } from './example-of-reactive-driveb-form-with-set-value-and-patch-value/example-of-reactive-driveb-form-with-set-value-and-patch-value.component';

const routes:Routes=[
  {path:'ReactiveDrivenForm' , component: ExampleOfReactiveDrivenFormComponent},
  {path:'NestedReactiveDrivenForm' , component: ExampleOfNestedReactiveDrivenFormComponent},
  {path:'NestedSetAndPatchReactiveDrivenForm' , component: ExampleOfReactiveDrivebFormWithSetValueAndPatchValueComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    ExampleOfReactiveDrivenFormComponent,
    ExampleOfNestedReactiveDrivenFormComponent,
    ExampleOfReactiveDrivebFormWithSetValueAndPatchValueComponent
  ],
  imports: [
    BrowserModule,FormsModule, ReactiveFormsModule,RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
