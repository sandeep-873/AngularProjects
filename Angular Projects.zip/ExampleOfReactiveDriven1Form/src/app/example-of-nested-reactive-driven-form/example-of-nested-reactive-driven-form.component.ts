import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validator } from "@angular/forms";

@Component({
  selector: 'app-example-of-nested-reactive-driven-form',
  templateUrl: './example-of-nested-reactive-driven-form.component.html',
  styleUrls: ['./example-of-nested-reactive-driven-form.component.css']
})
export class ExampleOfNestedReactiveDrivenFormComponent  {

  mygrp:FormGroup
  constructor(private myBuilder: FormBuilder) {
     this.mygrp=this.myBuilder.group({
      'username':'',
      'password':[],
      'confirmpassword':[],
      'age':[],
      'email':[],
      'phoneNo':[],
      'Dob':[],
      'address':this.myBuilder.group({
        'country':'',
        'state':'',
        'city':'',
        'pincode':''
      })
     })
   }

   SaveEmployee(temp:any){
    console.log(temp);
    
   }


}
