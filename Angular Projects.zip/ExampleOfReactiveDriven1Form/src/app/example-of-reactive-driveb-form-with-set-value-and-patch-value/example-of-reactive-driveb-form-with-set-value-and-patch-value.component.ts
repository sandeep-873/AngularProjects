import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validator } from "@angular/forms";

@Component({
  selector: 'app-example-of-reactive-driveb-form-with-set-value-and-patch-value',
  templateUrl: './example-of-reactive-driveb-form-with-set-value-and-patch-value.component.html',
  styleUrls: ['./example-of-reactive-driveb-form-with-set-value-and-patch-value.component.css']
})
export class ExampleOfReactiveDrivebFormWithSetValueAndPatchValueComponent {

  mygrp: FormGroup
  constructor(private myBuilder: FormBuilder) {
    this.mygrp = this.myBuilder.group({
      'username': '',
      'password': [],
      'confirmpassword': [],
      'age': [],
      'email': [],
      'phoneNo': [],
      'Dob': [],
      'address': this.myBuilder.group({
        'country': '',
        'state': '',
        'city': '',
        'pincode': ''
      })
    })
  }

  LoadAPIDataWithSetValue() {
    this.mygrp.setValue({

      'username': 'Saurabh',
      'password': 'agarwal',
      'confirmpassword': 'agarwal',
      'age': 39,
      'email': 'saurabh_srmcem@rediffmail.com',
      'phoneNo': 9971328227,
      'Dob': formatDate('08/28/1982','yyyy-MM-dd','en'),
      'address': {
         'country': 'India',
        'state': 'UP',
        'city': 'Noida',
        'pincode': '201301'
      }
    })

    

  }
  LoadAPIDataWithPatchValue() {
    this.mygrp.patchValue({

      'username': 'Saurabh',
      'password': 'agarwal',
      'confirmpassword': 'agarwal',
      'age': 39,
     // 'email': 'saurabh_srmcem@rediffmail.com',
      'phoneNo': 9971328227,
      'Dob': formatDate('08/28/1982','yyyy-MM-dd','en'),
      'address': {
        // 'country': 'India',
        'state': 'UP',
        'city': 'Noida',
       // 'pincode': '201301'
      }
    })

  }
  SaveEmployee(temp: any) {
    console.log(temp);

  }
}
