import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validator } from "@angular/forms";

@Component({
  selector: 'app-example-of-reactive-driven-form',
  templateUrl: './example-of-reactive-driven-form.component.html',
  styleUrls: ['./example-of-reactive-driven-form.component.css']
})
export class ExampleOfReactiveDrivenFormComponent  {

  mygrp:FormGroup
  constructor(private myBuilder: FormBuilder) {
     this.mygrp=this.myBuilder.group({
      'username':'',
      'password':[],
      'confirmpassword':[],
      'age':[],
      'email':[],
      'phoneNo':[],
      'Dob':[]
     })
   }

   SaveEmployee(temp:any){
    console.log(temp);
    
   }

 

}
