export class User
{
    id:number;
    name:string;
    username:string;
    email:string;
    address:Address;
 }
export class Address
{
    suite:string;
    city:string;
    street:string;
    zipcode:string;
    geo:GeoCordinates;
    
}

export class GeoCordinates
{
    lat:string;
    lng:string;
}