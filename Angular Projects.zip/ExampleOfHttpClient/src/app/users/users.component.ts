import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers:[UserService]
})
export class UsersComponent  {

  users:any;
  userbuttonclick:any;
  hideTableheader=false;
  userById:any;
  Id:number;
  name:string;
  constructor(private objUserService : UserService) { 

    this.objUserService.getAllUsers().subscribe(data=>{this.users=data;})
  }

  GetDatabyHttpClient(){
    this.objUserService.getAllUsers().subscribe(data=>
      {
        this.hideTableheader=true;
        this.userbuttonclick=data;
      })
  }

  GetHttpClientByName(name){
    this.objUserService.getUserByName(name).subscribe(data=>{this.userById=data;})

  }

  GetHttpClientById(id){
    this.objUserService.getUserById(id).subscribe(data=>{this.userById=data;})

  }


}
