import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-observable',
  templateUrl: './user-observable.component.html',
  styleUrls: ['./user-observable.component.css'],
  providers:[UserService]
})
export class UserObservableComponent  {

  users:User[];
  constructor(private objUserService : UserService) { 

    this.objUserService.getAllUsersbyObservables().subscribe(data=>{this.users=data;})
  }

  

}
