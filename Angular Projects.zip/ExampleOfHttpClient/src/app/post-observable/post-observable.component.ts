import { Component, OnInit } from '@angular/core';
import { Post } from '../Post';
import { PostService } from '../post.service';

@Component({
  selector: 'app-post-observable',
  templateUrl: './post-observable.component.html',
  styleUrls: ['./post-observable.component.css'],
  providers:[PostService]
})
export class PostObservableComponent  {

  posts:Post[];
  constructor(private objPostService : PostService) { 

    this.objPostService.getAllPostByObservable().subscribe(data=>{this.posts=data;})
  }

}
