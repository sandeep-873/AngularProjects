import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  getAllUsers(){
   return this.http.get("http://jsonplaceholder.typicode.com/users");
  }

  getUserById(id:number){
    return this.http.get("http://jsonplaceholder.typicode.com/users?id=" + id);
   }

   getUserByName(name:string){
    return this.http.get("http://jsonplaceholder.typicode.com/users?name=" + name);
   }


   getAllUsersbyObservables():Observable<User[]>{
    return this.http.get<User[]>("http://jsonplaceholder.typicode.com/users");
   }

}
