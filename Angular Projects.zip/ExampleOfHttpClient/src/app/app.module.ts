import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { UsersComponent } from './users/users.component';
import {RouterModule, Routes} from '@angular/router';
import { PostComponent } from './post/post.component';
import { CommentsComponent } from './comments/comments.component';
import {FormsModule} from '@angular/forms';
import { UserObservableComponent } from './user-observable/user-observable.component';
import { PostObservableComponent } from './post-observable/post-observable.component';

const routes:Routes=[
  {'path':'User', component:UsersComponent},
  {'path':'Post', component:PostComponent},
  {'path':'Comment', component:CommentsComponent},
  {'path':'UserObservable', component:UserObservableComponent},
  {'path':'PostObservable', component:PostObservableComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    PostComponent,
    CommentsComponent,
    UserObservableComponent,
    PostObservableComponent
  ],
  imports: [
    BrowserModule,HttpClientModule, RouterModule.forRoot(routes),FormsModule
  ],
  exports:[],
  providers: [RouterModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
