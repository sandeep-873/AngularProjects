import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';

@Component({
  selector: 'app-example-of-template-drivem-form-with-model',
  templateUrl: './example-of-template-drivem-form-with-model.component.html',
  styles: [
  ]
})
export class ExampleOfTemplateDrivemFormWithModelComponent  {

 empModel=new Employee('E-101','Saurabh',39,'saurabh_srmcem@rediffmail.com','9971328227')

  SaveEmployee(temp:any){
    console.log(temp.value);
    
  }

}
