import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ExampleOfTemplateDrivenFormComponent } from './example-of-template-driven-form/example-of-template-driven-form.component';
import {FormsModule} from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import { ExampleOfBootstrapTemplateDrivenFormComponent } from './example-of-bootstrap-template-driven-form/example-of-bootstrap-template-driven-form.component';
import { ExampleOfButtonsComponent } from './example-of-buttons/example-of-buttons.component';
import { TablesComponent } from './tables/tables.component';
import { ExampleOfPanelsComponent } from './example-of-panels/example-of-panels.component';
import { ExampleOfTemplateDrivemFormWithModelComponent } from './example-of-template-drivem-form-with-model/example-of-template-drivem-form-with-model.component';

const routes:Routes=[
  {path:'TemplareDrivenForm' , component:ExampleOfTemplateDrivenFormComponent},
  {path:'BootstrapTemplateDrivenForm' , component:ExampleOfBootstrapTemplateDrivenFormComponent},
  {path:'TemplateDrivenFormWithModels' , component:ExampleOfTemplateDrivemFormWithModelComponent},
  {path:'Buttons' , component:ExampleOfButtonsComponent},
  {path:'Tables' , component:TablesComponent},
  {path:'Panels' , component:ExampleOfPanelsComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    ExampleOfTemplateDrivenFormComponent,
    ExampleOfBootstrapTemplateDrivenFormComponent,
    ExampleOfButtonsComponent,
    TablesComponent,
    ExampleOfPanelsComponent,
    ExampleOfTemplateDrivemFormWithModelComponent
  ],
  imports: [
    BrowserModule,FormsModule, RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
