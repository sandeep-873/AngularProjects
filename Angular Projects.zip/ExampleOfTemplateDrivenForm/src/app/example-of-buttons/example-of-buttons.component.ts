import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-of-buttons',
  templateUrl: './example-of-buttons.component.html',
  styleUrls: ['./example-of-buttons.component.css']
})
export class ExampleOfButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
