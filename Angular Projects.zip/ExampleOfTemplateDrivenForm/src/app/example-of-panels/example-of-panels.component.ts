import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-of-panels',
  templateUrl: './example-of-panels.component.html',
  styleUrls: ['./example-of-panels.component.css']
})
export class ExampleOfPanelsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
