import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-of-bootstrap-template-driven-form',
  templateUrl: './example-of-bootstrap-template-driven-form.component.html',
  styleUrls: ['./example-of-bootstrap-template-driven-form.component.css']
})
export class ExampleOfBootstrapTemplateDrivenFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  SaveEmployee(temp:any){
    console.log(temp.value);
    
  }

  topics:string[]=["MongoDB","BO SQL", "SQL SERVER"]

}
