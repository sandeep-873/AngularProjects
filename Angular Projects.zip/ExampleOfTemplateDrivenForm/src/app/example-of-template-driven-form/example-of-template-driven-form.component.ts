import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-of-template-driven-form',
  templateUrl: './example-of-template-driven-form.component.html',
  styleUrls: ['./example-of-template-driven-form.component.css']
})
export class ExampleOfTemplateDrivenFormComponent  {

  SaveEmployee(temp:any){
   console.log(temp.value);
   
  }

}
