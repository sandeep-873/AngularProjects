export class Employee{
    constructor(
        public empCode:string,
        public empName:string,
        public empAge:number,
        public empEmail:string,
        public empPhone:string
    ){

    }
}