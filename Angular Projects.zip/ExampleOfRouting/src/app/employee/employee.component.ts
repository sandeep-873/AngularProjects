import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent  {

  employeeJson: any = [
    { "FirstName": "Saurabh", "LastName": "Agarwal", "Gender": "Male", "Age": 37 },
    { "FirstName": "Harish", "LastName": "Jannu", "Gender": "Male", "Age": 30 },
    { "FirstName": "Amita", "LastName": "Jhoshi", "Gender": "Female", "Age": 32 },
    { "FirstName": "Bulbuli", "LastName": "Ghosh", "Gender": "Female", "Age": 40 },
    { "FirstName": "Ankur", "LastName": "Agarwal", "Gender": "Male", "Age": 38 },

  ]

}
