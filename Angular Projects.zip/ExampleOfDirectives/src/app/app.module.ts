import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ExampleofComponentDirectiveComponent } from './exampleof-component-directive/exampleof-component-directive.component';
import { ExampleofStructuralDirectiveComponent } from './exampleof-structural-directive/exampleof-structural-directive.component';
import { ExampleofAttributeDirectiveComponent } from './exampleof-attribute-directive/exampleof-attribute-directive.component';
import { ExampleofCustomDirectiveComponent } from './exampleof-custom-directive/exampleof-custom-directive.component';
import {RouterModule, Routes} from '@angular/router';
import { ExampleOfSwitchCaseComponent } from './example-of-switch-case/example-of-switch-case.component';
import { ExampleOfngClassDirectiveComponent } from './example-ofng-class-directive/example-ofng-class-directive.component';

const routes:Routes=[
  {path:'ComponentDirective', component: ExampleofComponentDirectiveComponent},
  {path:'StructuralDirective', component: ExampleofStructuralDirectiveComponent},
  {path:'AttributeDirective', component: ExampleofAttributeDirectiveComponent},
  {path:'CustomDirective', component: ExampleofCustomDirectiveComponent},
  {path:'SwitchCase', component: ExampleOfSwitchCaseComponent},
  {path:'ngClass', component: ExampleOfngClassDirectiveComponent}
]


@NgModule({
  declarations: [
    AppComponent,
    ExampleofComponentDirectiveComponent,
    ExampleofStructuralDirectiveComponent,
    ExampleofAttributeDirectiveComponent,
    ExampleofCustomDirectiveComponent,
    ExampleOfSwitchCaseComponent,
    ExampleOfngClassDirectiveComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
