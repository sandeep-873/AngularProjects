import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exampleof-custom-directive',
  templateUrl: './exampleof-custom-directive.component.html',
  styleUrls: ['./exampleof-custom-directive.component.css']
})
export class ExampleofCustomDirectiveComponent  {

 

}
