import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exampleof-attribute-directive',
  templateUrl: './exampleof-attribute-directive.component.html',
  styleUrls: ['./exampleof-attribute-directive.component.css']
})
export class ExampleofAttributeDirectiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
