import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exampleof-structural-directive',
  templateUrl: './exampleof-structural-directive.component.html',
  styleUrls: ['./exampleof-structural-directive.component.css']
})
export class ExampleofStructuralDirectiveComponent  {

  isUserLoggedIn:boolean=false;
  show:boolean=false;
  a:number=80;
  b:number=50;

  person:any=[
    {"name":"Saurabh","age":37},
    {"name":"Padma","age":42},
    {"name":"Ashish","age":29},
    {"name":"Madhav","age":30},
    {"name":"Dinesh","age":28},
    {"name":"Ashwini","age":29},
    {"name":"Sabila","age":25},
    {"name":"Tushar","age":30},
    {"name":"Gayathri","age":28},
    {"name":"Anamika","age":29},
  ]

}
