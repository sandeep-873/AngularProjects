import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-ofng-class-directive',
  templateUrl: './example-ofng-class-directive.component.html',
  styleUrls: ['./example-ofng-class-directive.component.css']
})
export class ExampleOfngClassDirectiveComponent  {

  users:string[]=["Vishal","Anand","Pradeep","Pratik","Hemant","Asihwarya","Kalyani"];

}
