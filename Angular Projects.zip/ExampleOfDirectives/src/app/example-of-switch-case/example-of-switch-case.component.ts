import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-of-switch-case',
  templateUrl: './example-of-switch-case.component.html',
  styleUrls: ['./example-of-switch-case.component.css']
})
export class ExampleOfSwitchCaseComponent  {

 course:string="Angular";

}
