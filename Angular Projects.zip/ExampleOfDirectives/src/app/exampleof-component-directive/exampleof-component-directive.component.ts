import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exampleof-component-directive',
  templateUrl: './exampleof-component-directive.component.html',
  styleUrls: ['./exampleof-component-directive.component.css']
})
export class ExampleofComponentDirectiveComponent  {

  

}
